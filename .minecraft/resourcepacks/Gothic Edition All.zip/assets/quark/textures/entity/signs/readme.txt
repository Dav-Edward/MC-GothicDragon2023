listen they have to be here for vanilla to pick them up okay
it wasnt my choice to use this asinine directory structure